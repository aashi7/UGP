import tensorflow as tf
import numpy as np
import scipy.io.wavfile
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import cPickle, gzip

from tensorflow.python.client import timeline

# Load the dataset
f = gzip.open('mnist.pkl.gz', 'rb')
train_set, valid_set, test_set = cPickle.load(f)
f.close()


train_dataset = train_set[0]
train_labels = train_set[1]
train_dataset = train_dataset[:5000]
a = np.array(train_labels[:5000])
b = np.zeros((len(a), 10))
b[np.arange(len(a)), a] = 1
train_labels = b

valid_dataset = valid_set[0]
valid_dataset = valid_dataset[:1000]
valid_labels = valid_set[1]
a = np.array(valid_labels[:1000])
b = np.zeros((len(a), 10))
b[np.arange(len(a)), a] = 1
valid_labels = b

test_dataset = test_set[0]
test_labels = test_set[1]
a = np.array(test_labels)
b = np.zeros((len(test_labels), 10))
b[np.arange(len(test_labels)), a] = 1
test_labels = b

# MNIST train images: 55000x784
# want 55000x28x28x1

n_input = len(train_dataset)

train_dataset = train_dataset.reshape(n_input, 28, 28, 1 )
train_dataset = train_dataset.transpose(0, 1, 2, 3)

n_input = len(valid_dataset)

valid_dataset = valid_dataset.reshape(n_input, 28, 28, 1 )
valid_dataset = valid_dataset.transpose(0, 1, 2, 3)

n_input = len(test_dataset)

test_dataset = test_dataset.reshape(n_input, 28, 28, 1 )
test_dataset = test_dataset.transpose(0, 1, 2, 3)


print('Training set', train_dataset.shape, train_labels.shape)
print('Validation set', valid_dataset.shape, valid_labels.shape)
print('Test set', test_dataset.shape, test_labels.shape)


def accuracy(predictions, labels):
	return (100.0 * np.sum(np.argmax(predictions, 1) == np.argmax(labels, 1))/ predictions.shape[0])

batch_size = 16
image_size = 28
num_channels = 1
num_labels = 10
patch_size = 5
patch_size2 = 5
depth1 = 6
depth2 = 16
num_hidden = 120
num_hidden2 = 84

graph = tf.Graph()

finalRepresentations = []

with graph.as_default():

	# Input data
	tf_train_dataset = tf.placeholder(
		tf.float32, shape=(batch_size, image_size, image_size, num_channels))
	tf_train_labels = tf.placeholder(tf.float32, shape=(batch_size, num_labels))

	tf_valid_dataset = tf.constant(valid_dataset)
	tf_valid_labels = tf.constant(valid_labels)
	tf_test_dataset = tf.constant(test_dataset)
	
	# Variables
	layer1_weights = tf.Variable(tf.truncated_normal(
		[patch_size, patch_size, num_channels, depth1], stddev=0.1))         ## [filter_height, filter_width, in_channels, out_channels]
																			 ## [5, 5, 1, 6]
	layer1_biases = tf.Variable(tf.zeros([depth1]))

	# dropout
	keep_prob = tf.placeholder("float")

	layer2_weights = tf.Variable(tf.truncated_normal(
		[patch_size2, patch_size2, depth1, depth2], stddev=0.1))               ## [5, 5, 6. 16]
	layer2_biases = tf.Variable(tf.constant(1.0, shape=[depth2]))

	layer3_weights = tf.Variable(tf.truncated_normal([4,4,16,num_hidden], stddev=0.1))      ## [4, 4, 16, 120]
	layer3_biases = tf.Variable(tf.constant(1.0, shape=[num_hidden]))

	layer4_weights = tf.Variable(tf.truncated_normal(
		[num_hidden, num_hidden2], stddev=0.1))
	layer4_biases = tf.Variable(tf.constant(1.0, shape=[num_hidden2]))

	layer5_weights = tf.Variable(tf.truncated_normal(
		[num_hidden2, num_labels], stddev=0.1))
	layer5_biases = tf.Variable(tf.constant(1.0, shape=[num_labels]))


	# Model.
	def model(data):

	# layer1: Conv1 layer
	# Receptive Field 5 x 5 , input_channel 1, depth 16 
	# A cube of [24,24,16] 
	# Not doing zero padding

		conv1 = tf.nn.conv2d(data, layer1_weights, [1, 1, 1, 1], padding='VALID')
		print conv1.get_shape()
		hidden = tf.nn.relu(conv1 + layer1_biases)
	#	print hidden.get_shape()

	#   pooling
		pool1 = tf.nn.avg_pool(hidden, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
			padding='VALID', name='pool1')
		print pool1.get_shape()
		norm1 = tf.nn.lrn(pool1, 4, bias=1.0,   alpha=0.001 / 9.0, beta=0.75,
			name='norm1')

	#   layer2
		conv2 = tf.nn.conv2d(norm1, layer2_weights, [1, 1, 1, 1], padding='VALID')
		print conv2.get_shape()
		hidden = tf.nn.relu(conv2 + layer2_biases)
	#	print hidden.get_shape()
	#   pooling2
		pool2 = tf.nn.avg_pool(hidden, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
			padding='VALID', name='pool2')
		print pool2.get_shape()
		norm2 = tf.nn.lrn(pool2, 4, bias=1.0,   alpha=0.001 / 9.0, beta=0.75,
			name='norm2')


	#   layer3
		conv3 = tf.nn.conv2d(norm2, layer3_weights, [1, 1, 1, 1], padding='VALID')
		print conv3.get_shape()
		hidden = tf.nn.relu(conv3 + layer3_biases)
	#	print hidden.get_shape()


		shape = hidden.get_shape().as_list()
		hidden = tf.reshape(hidden, [shape[0], shape[1] * shape[2] * shape[3]])
		print hidden.get_shape()
	#   RELU
	#	hidden = tf.nn.relu(tf.matmul(reshape, layer3_weights) + layer3_biases)

		fc1 = tf.matmul(hidden, layer4_weights) + layer4_biases
		hidden = tf.nn.relu(fc1)
		print fc1.get_shape()

	# #   add a dropout
	#	hidden = tf.nn.dropout(hidden, keep_prob)

		fc2 = tf.matmul(hidden, layer5_weights) + layer5_biases
		print fc2.get_shape()

		return fc2


	# Training computation.
	logits = model(tf_train_dataset)
	loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits, tf_train_labels))
	
	tsne_rep = model(tf_test_dataset)

	# Learning rate decay
	step = tf.Variable(0, trainable=False)
	set_learning_rate = 0.001
	learning_rate = tf.train.exponential_decay(set_learning_rate, step,100000, 0.96, staircase=True)


	optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

	# Predictions for the training, validation, and test data.
	train_prediction = tf.nn.softmax(logits)
	a = model(tf_valid_dataset)
	loss_valid = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(a, tf_valid_labels))
	valid_prediction = tf.nn.softmax(a)
	test_prediction = tf.nn.softmax(model(tf_test_dataset))


num_steps = 80000

### For time taken by conv and fc layers ####

with tf.Session(graph=graph) as sess:
	run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
	run_metadata = tf.RunMetadata()
	init = tf.initialize_all_variables()
	sess.run(init)
	print('Initialized')
	sess.run(init)
	sess.run(test_prediction, options=run_options, run_metadata=run_metadata)
	tl = timeline.Timeline(run_metadata.step_stats)
	ctf = tl.generate_chrome_trace_format()
	with open('timeline_ten_examples.json', 'w') as f:
		f.write(ctf)

##################################################

training_error = []
iterations = []
validation_error = []

with tf.Session(graph=graph) as session:
	tf.initialize_all_variables().run()
	print('Initialized')
	for step in range(num_steps):
		offset = (step * batch_size) % (train_labels.shape[0] - batch_size)
		batch_data = train_dataset[offset:(offset + batch_size), :, :, :]
		batch_labels = train_labels[offset:(offset + batch_size), :]
		feed_dict = {tf_train_dataset : batch_data, tf_train_labels : batch_labels,keep_prob:1.0}

		_, l, predictions = session.run([optimizer, loss, train_prediction], feed_dict=feed_dict)
		if (step % 1000 == 0):

			print('Loss on minibatch at step %d: %f' % (step, l))
			training_error.append(l)
			iterations.append(step)
			print('Accuracy on the passed minibatch: %.1f%%' % accuracy(predictions, batch_labels))
			loss_validation = session.run(loss_valid)
			validation_error.append(loss_validation)
			print('Validation accuracy: %.1f%%' % accuracy(
#         valid_prediction.eval(), valid_labels))
							valid_prediction.eval(session=session,feed_dict={keep_prob:0.5}), valid_labels))

	print('Test accuracy: %.1f%%' % accuracy(test_prediction.eval(session=session,feed_dict={keep_prob:1.0}), test_labels))
	finalRepresentations = session.run(tsne_rep)

	final_layer_weights = layer5_weights.eval(session=session)   #  get the weights of the final layer in order to visualize

plt.figure(1)
plt.scatter(iterations, training_error)
plt.show()

plt.figure(2)
plt.scatter(iterations, validation_error)
plt.show()


def plot_tSNE(lowDWeights, labels, imagename='tsne_128.png'):
	assert lowDWeights.shape[0] >= len(labels), "More labels than weights"
	plt.figure(figsize=(20, 20))  #in inches
	for i, label in enumerate(labels):
		x, y = lowDWeights[i,:]
		plt.scatter(x, y)
		plt.annotate(label,
			xy=(x, y),
			xytext=(5, 2),
			textcoords='offset points',
			ha='right',
			va='bottom')

	plt.savefig(imagename)

tsne = TSNE(perplexity=30, n_components=2, init='pca', n_iter=5000)
plot_only = 6
lowDWeights = tsne.fit_transform(final_layer_weights)
labels = ['0','1','2','3','4','5','6','7','8','9']
plot_with_labels(lowDWeights, labels)

iters = 800
tsne = TSNE(perplexity=50, n_components=2, init='pca', n_iter=5000)
plot_only = 2000
lowDWeights = tsne.fit_transform(finalRepresentations[0:plot_only,:])
labels = testY[0:plot_only]
plot_with_labels(lowDWeights, labels, str(iters*100)+'.png')


######### Final Code Experiments #############
'''

Previous Implementaion:
Batch Size | Test Accuaracy | Validation Accuracy
16         |  98.1%         | 98.0%
32         |  98.1%         | 98.1%


Current Implementation:
16            94.8            93.8
32			  94.8            92.9
64			  95.1            93.7
128			  95.0            93.2			
	
'''


##############################################
