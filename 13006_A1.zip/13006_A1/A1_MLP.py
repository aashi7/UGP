import operator
import math
import random
import numpy as np
import matplotlib.pyplot as plt


gamma = 0.001          ## learning rate for (stochastic) gradient descent with momentum
alpha = 0.9            ## fraction of the update term of the past time step  (SGD with momentum)
epsilon_adagrad = 1e-8 ## Smoothing term in Adagrad Gradient Descent 

##### Loading the MNIST dataset with output as one-hot vector ##### 

import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data

mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)

## mnist.train.images, mnist.train.labels
## mnist.validation.images
## mnist.train.images

#print('Validation input:',mnist.validation.images.shape)
#print('Validation output:',mnist.validation.labels.shape)

###################################################################


class Node:

	def __init__(self, m_inputs, zjm, gradjm, node_output):

		# initialises a basic unit (node) of multilayer perceptron
		# where
		# m_inputs     dimension of input to the node                      int 1x1   
		# zjm          input to the node (fed into activation function)    float 1x1
		# node_ouput   output of the node = actfun(zjm)                    float 1x1
		# gradjm       derivative of error(cross-entropy) wrt node's input float 1x1


		self.m_inputs = m_inputs
		self.zjm = zjm
		self.node_output = node_output
		self.gradjm = gradjm

		# intialising the weights corresponding to each node from the layer below [m_inputs X 1]
		self.set_weights([random.uniform(-0.4,0.4) for x in range(0,m_inputs)])

		# initialising the bias to each node float 1x1
		self.bias = 0.

		# bias_check gradient for the bias computed numerically 
		self.bias_check = 0.

		# update term computed through backpropagation for each weight in gradient descent equation 
		self.set_update([0. for x in range(0,m_inputs)])

		# direction term for each weight (GD with momentum)
		self.set_directionjm([0. for x in range(0,m_inputs)])

		# Gradient with respect to weights computed numerically 
		self.set_grad_check([0. for x in range(0,m_inputs)])

		# Adagrad G_t for each parameter
		self.set_Gt([0. for x in range(0,m_inputs)])

		# Adagrad learning rate for each parameter
		self.set_eta([0.001 for x in range(0,m_inputs)])

	def sum(self,inputs):
		return sum(val*self.weights[i] for i,val in enumerate(inputs))    ### Wx

	# Adagrad: sum of past gradients
	def set_Gt(self, Gt):
		self.Gt = Gt

	# Adagrad: learning parameter for each weight
	def set_eta(self, eta):
		self.eta = eta

	def set_weights(self, weights):
		self.weights = weights

	# derivative of error wrt weight
	def set_update(self, update):
		self.update = update

	# past update for SGD with momentum
	def set_directionjm(self, directionjm):
		self.directionjm = directionjm

	# Gradient computed numerically
	def set_grad_check(self, grad_check):
		self.grad_check = grad_check

class HiddenLayer:

	def __init__(self, m_nodes, m_inputs):

		# initialises a hidden layer (including output layer) of multilayer perceptron
		# where
		# m_nodes     number of nodes in the layer          int 1x1   
		# m_inputs    number of nodes in the layer below    int 1x1

		self.m_nodes = m_nodes
		self.nodes = [Node(m_inputs=m_inputs, zjm=None, gradjm=None, node_output=None) for _ in range(0,self.m_nodes)]




class MLP:

	def __init__(self, n_inputs, n_outputs, nnodes, nhidden_layers, actfun):

		# initialises the multilayer perceptron 
		# where
		# n_inputs             dimension of the input                                       int 1x1    784       
		# n_ouputs             dimension of the output                                      int 1x1    10
		# nhidden_layers       number of hidden layers (excluding input and output layers)  int 1x1
		# nnodes               number of nodes in each layer                                int [nhidden_layers x 1]
		# actfun               activation function                                          int 1x1 

		self.n_inputs = n_inputs                 
		self.n_outputs = n_outputs
		self.nhidden_layers = nhidden_layers
		self.nnodes = nnodes

		self._create_network()
		self._n_weights = None
		self.actfun = actfun


	def _create_network(self):

			# create the first layer
			self.layers = [HiddenLayer(self.nnodes[0],self.n_inputs)]

			# create hidden layers
			self.layers += [HiddenLayer(self.nnodes[i],self.nnodes[i-1] ) for i in range(1, self.nhidden_layers)]    ## n_hidden_layers - 1

			# hidden-to-output layer
			self.layers += [HiddenLayer(self.n_outputs,self.nnodes[-1])]



	def get_weights(self):
		weights = []

		for layer in self.layers:
			for node in layer.nodes:
				weights += node.weights

		return weights


	def n_weights(self):
		if not self._n_weights:
			self._n_weights = 0
			for layer in self.layers:
				for node in layer.nodes:
					self._n_weights += node.n_inputs 
		return self._n_weights

	def set_weights(self, weights ):
		assert len(weights)==self.n_weights, "Incorrect amount of weights."

		stop = 0
		for layer in self.layers:
			for node in layer.nodes:
				start, stop = stop, stop+(node.n_inputs+1)
				node.set_weights( weights[start:stop] )
		return self

	def feed_forward(self, inputs ):
		assert len(inputs)==self.n_inputs, "Incorrect amount of inputs."

		for m,layer in enumerate(self.layers):

			if m==nhidden_layers:
				outputs = []
				for node in layer.nodes:
					tot = node.sum(inputs) + node.bias        ## Uy + b
					node.zjm = tot           ## zjm (node's input): required for computing gradients through backpropagation
					outputs.append(node.zjm) 
				## softmax(Uy + b)
				outputs = self.softmax(outputs)   ## output layer is the softmax layer

			else:
	
				outputs = []
				for node in layer.nodes:
					tot = node.sum(inputs) + node.bias
					node.zjm = tot           
					node.output = self.activation(tot)  ## activation function for the hidden layer
					outputs.append(node.output)
			
			inputs = outputs 

		return outputs

    ## Output layer 
	def softmax(self, vector):
		ans = []
		a = np.exp(vector)
		for i in range(len(vector)):
			ans.append(a[i]/sum(a))

		return ans

	## Activation functions for hidden layers

	def activation(self, scalar_value):

		if self.actfun:
			return max(0, scalar_value)
		else:
			return np.tanh(scalar_value)

	def dact(self, scalar_value):

		if self.actfun:
			if scalar_value > 0:
				return 0
			else:
				return 1
		else:
			return (1-(scalar_value**2))

	## Tanh
	#def tanh(self, scalar):
	#	return np.tanh(scalar)

	## Derivative of tanh to calculate gradients
	#def dtanh(self, scalar_value):
	#	return (1-(scalar_value**2))

	## Relu 
	#def relu(self, scalar_value):
	#	return max(0,scalar_value)

	## Derivative of Relu
	#def drelu(self, scalar_value):
	#	if scalar_value > 0:
	#		return 1
	#	else:
	#		return 0

	def backpropagate_output_layer(self, output, true_outputs):
		for i,node in enumerate(self.layers[-1].nodes):          ### output layer
			e = output[i] - true_outputs[i]
			node.gradjm = e
			node.bias = node.bias - gamma*node.gradjm
			for j in range(0,len(node.weights)):
				node.update[j] = node.gradjm*self.layers[-2].nodes[j].zjm
				node.directionjm[j] = node.directionjm[j]*alpha + gamma*node.update[j]
				node.weights[j] = node.weights[j] - node.directionjm[j]
				#node.Gt[j] += np.square(node.update[j])
				#node.eta[j] = gamma/np.sqrt(node.Gt[j]+epsilon_adagrad)
				#node.weights[j] = node.weights[j] - node.eta[j]*node.update[j]

		print self.layers[-1].nodes[0].weights
	


	def backpropagate_hidden_layer(self, m, inputs):
		for j,node in enumerate(self.layers[m].nodes):
			sum = 0.
			for node_above in self.layers[m+1].nodes:
				sum += node_above.gradjm*node_above.weights[j]*self.dact(node.zjm)
			node.gradjm = sum
			node.bias = node.bias - gamma*node.gradjm
			if (m>0):

				for k in range(0,len(node.weights)):
					node.update[k] =  node.gradjm*self.layers[m-1].nodes[k].zjm
					node.directionjm[k] = node.directionjm[k]*alpha + gamma*node.update[k]     # GD with momentum
					node.weights[k] = node.weights[k] - node.directionjm[k]					# GD with momentum

					#### Adagrad update ###
					#node.Gt[k] += np.square(node.update[k])									
					#node.eta[k] = gamma/np.sqrt(node.Gt[k]+epsilon_adagrad)
					#node.weights[k] = node.weights[k] - node.eta[k]*node.update[k]


			else:

				for k in range(0,len(inputs)):
					node.update[k] =  node.gradjm*inputs[k]
					node.directionjm[k] = node.directionjm[k]*alpha + gamma*node.update[k]
					node.weights[k] = node.weights[k] - node.directionjm[k]
					#node.Gt[k] += np.square(node.update[k])
					#node.eta[k] = gamma/np.sqrt(node.Gt[k]+epsilon_adagrad)
					#node.weights[k] = node.weights[k] - node.eta[k]*node.update[k]


	def validate(self, val_inputs, val_outputs):
		error = np.zeros(len(val_inputs))
		for i in range(0, len(val_inputs)):
			network_output = self.feed_forward(val_inputs[i])
			error[i] = -1*sum(val_outputs[i]*np.log(network_output))

		return sum(error)	


	def train(self, train_input, train_labels, val_data, val_labels):

		### n indicates the number of passes over the same training data
#		for n in range(0,1):

		#val_error = []
		#train_error = []

		### iterating over each example in the training data
		for k in range(0,len(train_input)):	

			output = my_MLP.feed_forward(train_input[k])
			#print output  
			#[10x1] vector giving the probability for each label 

			# Calculates the error over validation data
			if (k%500 == 0):
			#	error_val = self.validate(val_data, val_labels)
			#	print "error on validation data after %i iterations: %f" %(k, error_val)
				#error_train = self.validate(train_input, train_labels)
				#print "error on training data after %i iterations: %f" %(k, error_train)
			#	val_error.append((k,error_val))
				#train_error.append((k+k*n,error_train))
				print "%i" %k
			
			self.backpropagate_output_layer(output, train_labels[k])

			for i in range(nhidden_layers-1, -1, -1):
				self.backpropagate_hidden_layer(i, train_input[k])

		#fig = plt.figure()
		#fig.suptitle('Train and Validation error (actfun=Relu, SGD with momentum, 1 layer - 256 Nodes) ', fontsize=12, fontweight='bold')
		
		plt.plot(*zip(*val_error))

		#plt.plot(*zip(*train_error))
		plt.show()


	def test(self, test_data, test_labels):

		count = 0.
		for i in range(0,len(test_data)):
			output = my_MLP.feed_forward(test_data[i])
			max_index = max(enumerate(output), key=operator.itemgetter(1))
			max_index_true = max(enumerate(test_labels[i]),  key=operator.itemgetter(1))
			if max_index[0]==max_index_true[0]:
				count+=1

		print count
		return count/len(test_data)

	def plotgradient(self, inputs, true_outputs):
		n=0
		output = my_MLP.feed_forward(inputs)

		plot_gradient = []
		node = self.layers[-1].nodes[4]

		# adding epsilon to node's bias
		node.bias += epsilon

		# Finding the gradient of cross-entropy loss wrt the node's bias
		J_theta_plus_epsilon = -1*sum(true_outputs*np.log(output))    ## J(theta+epsilon)
		node.bias -= (2*epsilon)
		output = my_MLP.feed_forward(inputs)
		J_theta_minus_epsilon = -1*sum(true_outputs*np.log(output))   ## J(theta-epsilon)
		node.bias_check = (J_theta_plus_epsilon - J_theta_minus_epsilon)/(2*epsilon)
		node.bias += epsilon

		for j in range(0, len(node.weights)):	
			node.weights[j] += epsilon
			output = my_MLP.feed_forward(inputs)
			J_theta_plus_epsilon = -1*sum(true_outputs*np.log(output))
			node.weights[j] -= (2*epsilon)
			output = my_MLP.feed_forward(inputs)
			J_theta_minus_epsilon = -1*sum(true_outputs*np.log(output))
			node.grad_check[j] = (J_theta_plus_epsilon - J_theta_minus_epsilon)/(2*epsilon)
			node.weights[j] += epsilon
			n+=1

		my_MLP.backpropagate_output_layer(output, true_outputs)

		for i in range(nhidden_layers-1, -1, -1):
			my_MLP.backpropagate_hidden_layer(i, inputs)

		plot_gradient.append((n,node.gradjm-node.bias_check))
		n+=1

		for j in range(0, len(node.weights)):
			plot_gradient.append((n,node.update[j] - node.grad_check[j]))
			n+=1

		plt.scatter(*zip(*plot_gradient))
		plt.show()


nhidden_layers = 1
my_MLP = MLP(28*28, 10, [500], nhidden_layers=nhidden_layers, actfun=0)
## actfun - 1 : Relu,  0 : Tanh

my_MLP.train(mnist.train.images[:5000], mnist.train.labels[:5000], mnist.validation.images[:500], mnist.validation.labels[:500])

accuracy = my_MLP.test(mnist.test.images[:500], mnist.test.labels[:500])

print "accuracy: %f" %(accuracy)

### To check gradients
epsilon = 0.0001

## my_MLP.plotgradient(mnist.train.images[0], mnist.train.labels[0])

